# APIRequestLoader
 MVVM (Model View ViewModel) + Data Binding + Singleton + Generic API Calls + SOLID Principle
