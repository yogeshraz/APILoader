//
//  ApiEndPoints.swift
//  LearningApp
//
//  Created by Yogesh Raj on 20/11/21.
//

public enum ApiEndPoints: String {
    case login = "webservices/login"
    case devices = "sch_api/device_list.php"
    case getLastCoord = "sch_api/device_last_data.php"
    case webservices = "sch_api/webservices.php"
    
    case profile = "auth/me"
    case forgot = "password/reset"
    case country = "common/country"
    case state = "common/state"
    case city = "common/city"
    case timeZone = "common/timezone"
    case changePassword = "user/changepassword"
    case logout = "auth/logout"
    case profileImage = "user/profilepicture"
    case updateProfile = "user/updateuser/student"
    case discoverCourse = "common/course/listing?page="
    case categories = "common/categories"
    case myCourse = "student/course/an-listing?page="
    case courseConsumption = "student/course/"
    case rating = "student/course/rating"
    case popular = "common/popular/course/listing"
    case markViewed = "student/topic/view"
    case search = "common/course/search"
    case event = "student/event/listing?page="
    case eventDetail = "student/eventdetail/"
    
    case getCount = "notification/count"
    case read  = "notification/read"
    case isRegisterShow  = "is_register-show"
    public var value: String { rawValue }
}


