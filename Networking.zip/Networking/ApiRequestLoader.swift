//
//  ApiRequestLoader.swift
//  LearningApp
//
//  Created by Yogesh Raj on 20/11/21.
//

import UIKit

public enum BaseUrl: String {
    case url = "http://jpis.keendroid.com/"
    
    public var value: String { rawValue }
}

// MARK: - API Request Loader
class ApiRequestLoader: NSObject {
    
    static let shareInstance = ApiRequestLoader()
    
    // MARK: - Get Post String
    func getPostString(params:[String:Any]) -> String {
        
        var data = [String]()
        for(key, value) in params
        {
            data.append(key + "=\(value)")
        }
        return data.map { String($0) }.joined(separator: "&")
    }
    
    
    // MARK: - Simple Post Request
    func makeRequest(requestType: HTTPMethod, apiEndPoint: String, parameter: [String : Any], completionHandler: @escaping (AnyObject) -> (), networkError: @escaping (String?) -> ()) {
        
        //Post
        let post = self.getPostString(params: parameter)
        print(post)
        let postData = post.data(using: .ascii, allowLossyConversion: true)
        
        //Request
        let requestUrl = BaseUrl.url.value + apiEndPoint
        let url = URL(string: requestUrl)!
        print("****************\(url)****************")
        var request = URLRequest(url: url)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.httpMethod = requestType.rawValue
        request.httpBody = postData
        
        let sessionConfig = URLSessionConfiguration.default
        sessionConfig.timeoutIntervalForRequest = 30.0
        sessionConfig.timeoutIntervalForResource = 30.0
        //sessionConfig.httpAdditionalHeaders = finalRequest.headers
        
        let session = URLSession(configuration: sessionConfig, delegate: self as? URLSessionDelegate, delegateQueue: OperationQueue.main)
        let task = session.dataTask(with: request as URLRequest) {
            (
                data, response, error) in
            
            guard let data = data, let _:URLResponse = response, error == nil else {
                print("error")
                //AppManager.showToast(error!.localizedDescription, view: view)
                networkError(error?.localizedDescription)
                return
            }
            let dataString =  String(data: data, encoding: String.Encoding.utf8)
            print(dataString ?? "")
            
            guard let json = try? JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary else {
                
                //AppManager.showToast("Something went wrong.", view: view)
                networkError(error?.localizedDescription)
                return
            }
            
            let status = json.object(forKey: "status") as! String
            
            if status == "200" {
                completionHandler(json)
            } else if status == "401" {
                networkError(json.object(forKey: "message") as? String ?? "")
            } else {
                networkError(json.object(forKey: "message") as? String ?? "")
            }
        }
        task.resume()
    }
}
